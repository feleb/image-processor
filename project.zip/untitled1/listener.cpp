#include "listener.h"
#include <QMouseEvent>
#include <QPoint>
#include <QWidget>
listener::listener(QWidget *parent) : QLabel(parent){}

   /* void listener::mousePressEvent(QMouseEvent *event){
        intial=event->pos();
    }
    void listener::mouseReleaseEvent(QMouseEvent *event){
        end_point=event->pos();
    }
    QPoint listener::get_intial_point(){
        return intial;
    }
    QPoint listener::get_end_point(){
        return end_point;
    }*/

