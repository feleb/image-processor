#ifndef LISTENER_H
#define LISTENER_H
#include <QPoint>
#include <listener.h>
#include <QLabel>
#include <QMouseEvent>
#include <QDebug>
#include <QEvent>


class listener :public QLabel
{
     Q_OBJECT
public:
    explicit listener(QWidget *parent=0);
    QPoint get_intial_point();
    QPoint get_end_point();
protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
private:
QPoint intial,end_point;
};

#endif // LISTENER_H
