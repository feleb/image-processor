#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:

    void on_pushButton_clicked();

    void on_label_linkActivated(const QString &link);

    void on_scrollArea_objectNameChanged(const QString &path);

    void on_Rotate_Right_clicked();

    void on_pushButton_2_clicked();

    void on_ZoomIn_clicked();

    void on_Stop_rotation_clicked();

    void on_Rotate_Left_clicked();

    void on_ZoomOut_clicked();

    void on_reset_clicked();

    void on_pushButton_3_clicked();

    void on_dial_valueChanged(int value);

    void on_Undo_clicked();

    void on_dial_sliderReleased();

private:
    Ui::MainWindow *ui;
    QStack<QImage> *history;
};

#endif // MAINWINDOW_H
