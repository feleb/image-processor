
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QPainter>
#include <QMouseEvent>//new
#include <QPoint> //new
#include <iostream>//new
#include <QRect>//new
#include <QStack>
#include <QRubberBand>



float couner = 0.0;
int on_off = 1;
QString fileName;
QImage *ImageObject;
QImage *firstImage;
QRubberBand *rubber;
double scale_factor;
QPoint intial,end; //new
bool in_label=true;
QPoint label_top,label_bottom;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->main_label->setScaledContents(true);
    label_top.setX(ui->main_label->geometry().x());
    label_top.setY(ui->main_label->geometry().y());
    label_bottom.setX(ui->main_label->geometry().x()+ui->main_label->geometry().width());
    label_bottom.setY(ui->main_label->geometry().y()+ui->main_label->geometry().height());
    history = new QStack<QImage>;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    fileName = QFileDialog::getOpenFileName(this,
           tr("Load Image"), "",
           tr(" (*.jpg);;(*.png);;(*.bmp);;All Files (*)"));
   on_scrollArea_objectNameChanged(fileName);

}

void MainWindow::on_label_linkActivated(const QString &link)
{

}

void MainWindow::on_scrollArea_objectNameChanged(const QString &link)
{
    ImageObject = new QImage();
    ImageObject->load(link);
    history->push(*ImageObject);
    firstImage = new QImage();
    *firstImage = *ImageObject;
    QPixmap image = QPixmap::fromImage(*ImageObject);
        ui->main_label->setPixmap(image);
      //  ui->scrollArea->setWidgetResizable(true);
       // scrollArea = new QScrollArea;
        ui->scrollArea->setBackgroundRole(QPalette::Dark);
         ui->scrollArea->setWidget(ui->main_label);
         //showFullScreen();

}
//QPixmap currImage;
void MainWindow::on_Rotate_Right_clicked()
{
    on_off = 1;
    QPixmap ship(fileName);
        while(on_off == 1){

       // ui->main_label->clear();
       // ui->scrollArea->clearFocus();
        QApplication::processEvents();

        QPixmap ship(fileName);
        QPixmap rotate(ship.size());

        QPainter p(&rotate);
        p.setRenderHint(QPainter::Antialiasing);
        p.setRenderHint(QPainter::SmoothPixmapTransform);
        p.setRenderHint(QPainter::HighQualityAntialiasing);
        p.translate(rotate.size().width() / 2, rotate.size().height() / 2);
        ui->main_label->setText("");
        p.rotate(couner);

        p.translate(-rotate.size().width() / 2, -rotate.size().height() / 2);

        p.drawPixmap(0, 0, ship);
        p.end();
     ui->main_label->autoFillBackground();

       // ui->main_label->setBackgroundRole(QPalette::Dark);
        ui->main_label->setPixmap(rotate);
        *ImageObject = ship.toImage();
        couner = (couner+0.5);
        if(couner >= 360) couner = 0;
    }
    history->push(*ImageObject);
}


void MainWindow::on_Stop_rotation_clicked()
{
    on_off=0;
}


void MainWindow::on_ZoomIn_clicked()
{
    int width=label_bottom.x()-label_top.x();
    int height=label_bottom.y()-label_top.y();
    ui->main_label->setPixmap(ui->main_label->pixmap()->scaled(1.25*ui->main_label->width(),1.25*ui->main_label->height(),Qt::KeepAspectRatio));
}

void MainWindow::on_ZoomOut_clicked()
{
    int width=label_bottom.x()-label_top.x();
    int height=label_bottom.y()-label_top.y();
    ui->main_label->setPixmap(ui->main_label->pixmap()->scaled(0.8*ui->main_label->width(),0.8*ui->main_label->height(),Qt::KeepAspectRatio));
}

void MainWindow::on_reset_clicked()
{

   /* ui->main_label->adjustSize();
    scale_factor=1;
    ui->main_label->setScaledContents(false);*/
    QPixmap image = QPixmap::fromImage(*firstImage);
    ui->main_label->setPixmap(image);\
    while(!history->isEmpty())
        history->pop();

}

void MainWindow::on_Rotate_Left_clicked()
{
    on_off = 2;
        while(on_off == 2){

       // ui->main_label->clear();
       // ui->scrollArea->clearFocus();
        QApplication::processEvents();

        QPixmap ship(fileName);
        QPixmap rotate(ship.size());

        QPainter p(&rotate);
        p.setRenderHint(QPainter::Antialiasing);
        p.setRenderHint(QPainter::SmoothPixmapTransform);
        p.setRenderHint(QPainter::HighQualityAntialiasing);
        p.translate(rotate.size().width() / 2, rotate.size().height() / 2);
        ui->main_label->setText("");
        p.rotate(couner);

        p.translate(-rotate.size().width() / 2, -rotate.size().height() / 2);

        p.drawPixmap(0, 0, ship);
        p.end();
     ui->main_label->autoFillBackground();

       // ui->main_label->setBackgroundRole(QPalette::Dark);
        ui->main_label->setPixmap(rotate);
        *ImageObject = ship.toImage();

        couner = (couner-0.5);
        if(couner >= 360) couner = 0;
    }
        history->push(*ImageObject);
}

void MainWindow::on_pushButton_2_clicked()
{
        QString imagePath = QFileDialog::getSaveFileName(
                            this,
                            tr("Save File"),
                            "",
                            tr("JPEG (*.jpg *.jpeg);;PNG (*.png)" )
                            );
        QPixmap imag = QPixmap::fromImage(*ImageObject);
            *ImageObject = imag.toImage();
            ImageObject->save(imagePath);
}
void QWidget::mousePressEvent(QMouseEvent *event){
    if (event->pos().x()<label_top.x()||event->pos().y()<label_top.y()||event->pos().x()>label_bottom.x()||event->pos().y()>label_bottom.y())
        in_label=false;
    else{
        if (!rubber)
             rubber =new QRubberBand(QRubberBand::Rectangle,this);
       intial=event->pos();
       rubber->setGeometry(QRect(intial,QSize()));
       rubber->show();
       in_label=true;
    }
    //std::count<Mintial.x()<<std::endl;
}
void QWidget::mouseMoveEvent(QMouseEvent *event){
    if (in_label)
        rubber->setGeometry(QRect(intial,event->pos()).normalized());
}

void QWidget::mouseReleaseEvent(QMouseEvent *event){
    if (in_label)
    end=event->pos();
   // QPoint end_point=event->pos();
}

void MainWindow::on_pushButton_3_clicked()
{
    int min_x,min_y,width,height;
    if (intial.x()<end.x()){
        min_x=intial.x();
        width=end.x()-min_x;
    }else{
        min_x=end.x();
        width=intial.x()-min_x;
    }if (intial.y()<end.y()){
        min_y=intial.y();
        height=end.y()-min_y;
    }else{
        min_y=end.y();
        height=intial.y()-min_y;
     }
    QRect rect(min_x,min_y,width,height);
   // QImage original(fileName);
    QImage cropped = ImageObject->copy(rect);
    QPixmap image = QPixmap::fromImage(cropped);
    ui->main_label->setPixmap(image);
}

void MainWindow::on_dial_valueChanged(int value)
{
    QPixmap* pixmap = new QPixmap(fileName);
    QTransform transform;
    QTransform trans = transform.rotate(value);
    QPixmap *transPixmap = new QPixmap(pixmap->transformed(trans));
    ui->main_label->setPixmap(*transPixmap);
    *ImageObject = transPixmap->toImage();
}

void MainWindow::on_Undo_clicked()
{
    if(history->size()==1)return;
    history->pop();
    *ImageObject = history->top();

    QPixmap image = QPixmap::fromImage(*ImageObject);
    ui->main_label->setPixmap(image);
}

void MainWindow::on_dial_sliderReleased()
{
    std::cout<<"fsajfh"<<std::endl;
    history->push(*ImageObject);
    std::cout<<history->size()<<std::endl;
}
